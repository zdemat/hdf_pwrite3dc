To build the documentation in this directory,

    sphinx-build . _build_html

The output will be saved as html in `_build_html/`.
