Changes in IOR
**************

.. include:: ../../NEWS
